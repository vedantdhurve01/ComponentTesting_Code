package authtypes;

import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.*;

public class BasicAuth {

	
	@Test
	public void basicAuth()
	{
		baseURI = "http://postman-echo.com";
		
			given() 
			 	.accept("applicaton/json")
			 	.contentType("application/json")
			 	.auth().basic("postman","password")
			 
			 	.when()
			 		.get("/basic-auth")
			 		
			 	.then()
			 		.statusCode(200)
			 		.body("authenticated", equalTo(true))
			 		.log().all();
		
		
	}
}
