package authtypes;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

public class APIKeyAuth {
	

@Test
public void apiKeyAuth()
{
	baseURI = "http://api.openweathermap.org";
	String apikey = "13961857c9ccaafc9a02bded605f09a0";
	
		given() 
		 	.accept("applicaton/json")
		 	.contentType("application/json")
		 	.queryParam("q", "Pune")
		 	.queryParam("cnt", "4")
		 	.queryParam("appid", apikey)
		 	
		 
		 	.when()
		 		.get("/data/2.5/forecast/daily")
		 		
		 	.then()
		 		.statusCode(200)
		 		.log().all();
	
	
}


}
