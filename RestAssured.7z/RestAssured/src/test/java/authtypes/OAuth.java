package authtypes;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.*;

public class OAuth {


@Test
public void oAuth()
{
	baseURI = "https://api.github.com";
	String token = "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";
	
		given() 
		 	.accept("applicaton/json")
		 	.contentType(ContentType.JSON)
		 	.auth().oauth2(token)
		 	
		 
		 	.when()
		 		.get("/user/repos")
		 		
		 	.then()
		 		.statusCode(200)
		 		.log().all();
	
	
}

}
