package reqesttypes;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.*;

import org.json.simple.JSONObject;

public class PutTest {
	
	@Test
	public void putTest()
	{
		
		
		baseURI = "https://reqres.in";
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("name", "john Smith");
		jsonObject.put("job", "Tester");
		
		System.out.println(jsonObject.toString());
		
		given()
			.accept("application/json")
			.contentType("application/json")
			.body(jsonObject.toJSONString())
			
		.when()
			.put("/api/users/2")
			
		.then()
			.statusCode(200)
			.log().all();
	}

}
