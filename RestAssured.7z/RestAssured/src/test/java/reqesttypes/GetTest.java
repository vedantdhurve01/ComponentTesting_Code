package reqesttypes;

import org.testng.Assert;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.*;


public class GetTest {
	
	// TDD test cases 

@Test
public void getTest()
{
	Response res =RestAssured.get("https://reqres.in/api/users?page=2");
	System.out.println(res.statusCode());
	
	Assert.assertEquals(res.statusCode(), 200);
	}

@Test
public void getTestBDD()
{
	baseURI = "https://reqres.in";
	given()
		.accept("appication/json")
		.queryParam("page", "2")
		.contentType(ContentType.JSON)
	
	.when()
		.get("/api/users")
		
	.then()
		.statusCode(200)
		.body("data[1].id", equalTo(8))
		.body("data.first_name", hasItems("Rachel"))
		.log().all();
	
}
}