package reqesttypes;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class PatchTest {
	
	@Test
	public void patchTest()
	{
		baseURI = "https://reqres.in";
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("name", "Dhananjay Kawar");
		jsonObject.put("job", "Manager");
		
		/*
		 * jsonObject.put("name", "Prasad "); jsonObject.put("job", "Line Manager");
		 */
		
		System.out.println(jsonObject.toString());
		
		given()
			.accept("application/json")
			.contentType("application/json")
			.body(jsonObject.toJSONString())
			
		.when()
			.patch("/api/users/2")
			
		.then()
			.statusCode(200)
			.log().all();
	}

}
