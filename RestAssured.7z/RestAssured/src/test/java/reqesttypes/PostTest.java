package reqesttypes;

import org.testng.annotations.Test;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.*;

import org.json.simple.JSONObject;

public class PostTest {
	
	@Test
	public void postTest()
	{
		baseURI = "https://reqres.in";
		
		JSONObject jsonObject = new  JSONObject();
		jsonObject.put("name", "John");
		jsonObject.put("job", "Dev");
		
		System.out.println(jsonObject.toJSONString());
		
		given()
			.accept("application/json")
			.contentType("application/json")
			.body(jsonObject.toJSONString())
			
		.when()
			.post("/api/users")
			
		.then()
			.statusCode(201)
			.log().all();
		
		
	}

}
