package reqesttypes;

import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;

public class DeleteTest {
	
	@Test
	public void deleteTest()
	{
		baseURI = "https://reqres.in";
		
		when()
			.delete("/api/user/2")
		.then()
			.statusCode(204)
			.log().all();
	}

}
