package Channing;

import org.json.simple.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class CreateUser {
	
	@Test
	public void createUser(ITestContext context)
	{
		baseURI = "https://gorest.co.in";
		String bearerToken = "e0959520fb1196e8ea56688d767619c7c02e7e8b44195df16d1b8469c46b18f4";
		
		Faker faker = new Faker();
		
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("name", faker.name().fullName());
		jsonObject.put("gender", "male");
		jsonObject.put("email", faker.internet().emailAddress());
		jsonObject.put("status", "inactive");
		
		
		
		
		int id = given()
		.header("Authorization", "Bearer "+ bearerToken )
			.accept("application/json")
			.contentType(ContentType.JSON)
			.body(jsonObject.toJSONString())
			
		.when()
			.post("/public/v2/users")
			
		.then()
			.statusCode(201)
			.log().all()
			.extract().jsonPath().getInt("id");
		
		System.out.println("Get user class /n User Id - "+id);
		//context.setAttribute("user_id", id); // set Test level
		context.getSuite().setAttribute("user_id", id); // set a Suite level
	}

}
