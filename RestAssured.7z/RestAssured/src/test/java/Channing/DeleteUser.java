package Channing;

import org.json.simple.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.*;

public class DeleteUser {
	
	@Test
	public void deleteUser(ITestContext context)
		{
		baseURI = "https://gorest.co.in";
		String bearerToken = "e0959520fb1196e8ea56688d767619c7c02e7e8b44195df16d1b8469c46b18f4";
		
		//int id =(int) context.getAttribute("user_id"); // At test level
		
		int id =(int) context.getSuite().getAttribute("user_id"); // At Suite level
		
		given()
			.header("Authorization", "Bearer "+ bearerToken )
			.accept("application/json")
			.contentType(ContentType.JSON)
			.pathParam("id", id)
		
		.when()
			.delete("/public/v2/users/{id}")
		.then()
				.statusCode(204)
				.log().all();
		
		System.out.println("Delete User Class");
		}
	
	
	
	

}
