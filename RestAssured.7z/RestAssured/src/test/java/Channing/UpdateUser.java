package Channing;

import static io.restassured.RestAssured.baseURI;
import static io.restassured.RestAssured.given;

import org.json.simple.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.Test;
import com.github.javafaker.Faker;

import io.restassured.http.ContentType;

public class UpdateUser {
	
	@Test
	public void updateUser(ITestContext context)
	{
		baseURI = "https://gorest.co.in";
		String bearerToken = "e0959520fb1196e8ea56688d767619c7c02e7e8b44195df16d1b8469c46b18f4";
		
		//int id =(int) context.getAttribute("user_id"); // At test level
		int id =(int) context.getSuite().getAttribute("user_id"); // At Suite level
		
		Faker faker = new Faker();
		
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("name", faker.name().fullName());
		jsonObject.put("gender", "male");
		jsonObject.put("email", faker.internet().emailAddress());
		jsonObject.put("status", "active");
		
		given()
			.header("Authorization", "Bearer "+ bearerToken )
			.accept("application/json")
			.contentType(ContentType.JSON)
			.body(jsonObject.toJSONString())
			.pathParam("id", id)
		
		.when()
			.put("/public/v2/users/{id}")
		
			.then()
				.statusCode(200)
				.log().all();
			
		System.out.println("Update User class");
	}

}
